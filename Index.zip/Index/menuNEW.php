<?php
include "./Admin/Connection.php";
?>
<html>

<head>

  <style>
    h1 {
      font-size: 100px;
    }

    div.a {
      text-align: center;
    }

    .topnav {
      background-color: #333;
      overflow: hidden;
    }

    .topnav a {
      float: left;
      display: block;
      color: #FF8C00;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
      font-size: 17px;
    }

    body {
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
    }

    .topnav {
      overflow: hidden;
      background-color: #333;
    }

    .topnav a:hover {
      background-color: #FF8C00;
      color: black;
    }

    .topnav.icon {
      display: none;
    }

    body {
      font: 14px Arial, Sans-serif;
      margin: 0px;
    }




    .container {
      width: 100%;
      background: white;
    }


    .nav,
    .section {
      float: left;
      padding: 0px;
      min-height: 800px;
      box-sizing: border-box;
    }



    .section {
      width: 100%;
      min-height: 300px;
      max-height: 300px;
    }


    .nav ul {
      list-style: none;
      line-height: 24px;
      padding: 0px;
    }


    .clearfix:after {
      content: ".";
      display: block;
      height: 0;
      clear: both;
      visibility: hidden;
    }

    .footer {
      background: #20B2AA;
      text-align: center;
      padding: 5px;
    }


    .footer {
      position: fixed;
      left: 0;
      bottom: 0;
      width: 100%;
      background-color: #333;
      color: white;
      text-align: center;
      font-size: 20px;

    }

    /* IMAGE FADE CSS */


    h1 {
      /* text-shadow: 6px 6px pink; */
    }

    p {
      /* color: blue; */
      font-size: 20;
    }

    body {
      background-color: linen;
    }

    #mouse {
      background-color: green;
    }

    .me {
      font-size: 100px;
    }

    .shadow {
      box-shadow: 4px 6px pink;
    }

    .color img {
      filter: grayscale(100%);
      -webkit-filter: grayscale(100%);
      -webkit-transition: all 1s ease;
    }

    .brighten img {
      -webkit-filter: brightness(50%);
      -webkit-transition: all 1s ease;
      -moz-transition: all 1s ease;
      -o-transition: all 1s ease;
      -ms-transition: all 1s ease;
      transition: all 1s ease;
    }

    .brighten img:hover {
      -webkit-filter: brightness(100%);
    }

    /* IMAGE FADE CSS */
  </style>

</head>

<body>


  <div class="a">
    <img src="image/cat.jpg" width="200px" height="200px" align="right"></h1>
    <h1 style="background-color:black; color:white;">Burger Kitten....

      <div class="topnav">
        <a class="active" href="home page.html">Home</a>
        <a href="menuNEW.php">Menu</a>
        <a href="Book_a_table.html">Book a Table</a>

      </div>
  </div>

  <h1>

    <font color='#FAAFBE'>
      <center>Menu....</center>
    </font>
  </h1>


  <p style="font-size:100px;"><u>Burgers....</u></p>

  <table>
    <tr>
    <?php

$selectAll="SELECT * FROM `bugurs`";

$result=mysqli_query($conn,$selectAll);

if($result){
  // echo "Good";
}else{
  // echo "Error";
}

while($row=mysqli_fetch_assoc($result)){
  $product=$row['itemno'];
  $name=$row['name'];
  $price=$row['price'];
  $size=$row['size'];
  $image=$row['image'];
?>
      <td>


        <div class='brighten'>
          <img src="./Admin/Items/<?php echo $image ?>" width="500px" height="400px">
        </div>
      </td>
      <td>
        <p style="font-size:60px;"><?php echo $name ?></p>
        <p style="font-size:30px;"><?php echo $price ?>/=</p>
        <p style="font-size:20px;">(<?php echo $size ?>)</p>
      </td>




      <!-- <td>
        <div class='brighten'>
          <img src="image/egg.webp" width="500px" height="400px">
        </div>
      </td>
      <td>
        <p style="font-size:60px;">Egg Burger....</p>
        <p style="font-size:30px;">Rs.500/=</p>
        <p style="font-size:20px;">(Medium Size.)</p>
      </td> -->
    </tr>
    <?php } ?>



    <!-- <tr>
      <td>
        <br><br>
        <div class='brighten'>
          <img src="image/fish burger.webp" width="500px" height="400px">
        </div>
      </td>
      <td>
        <p style="font-size:60px;">Fish Burger....</p>
        <p style="font-size:30px;">Rs.550/=</p>
        <p style="font-size:20px;">(Medium Size.)</p>
      </td>


      <td>
        <br><br>
        <div class='brighten'>
          <img src="image/pork burger.webp" width="500px" height="400px">
        </div>
      </td>
      <td>
        <p style="font-size:60px;">Pork Burger....</p>
        <p style="font-size:30px;">Rs.850/=</p>
        <p style="font-size:20px;">(Medium Size.)</p>
      </td>
    </tr>


    <tr>
      <td>
        <br><br>
        <div class='brighten'>
          <img src="image/prawns.jpg" width="500px" height="400px">
        </div>
      </td>
      <td>
        <p style="font-size:60px;">Prawns Burger....</p>
        <p style="font-size:30px;">Rs.1050/=</p>
        <p style="font-size:20px;">(Medium Size.)</p>
      </td>


      <td>
        <br><br>
        <div class='brighten'>
          <img src="image/vegi burger.jpg" width="500px" height="400px">
          <div>
      </td>
      <td>
        <p style="font-size:60px;">Vegi Burger....</p>
        <p style="font-size:30px;">Rs.500/=</p>
        <p style="font-size:20px;">(Medium Size.)</p>
      </td>
    </tr>


    <tr>
      <td colspan="4">
        <br>
        <p style="font-size:100px;"><u>Beverages....</u></p>
        <br>
      </td>
    </tr>

    <tr>
      <td>
        <div class='brighten'>
          <img src="image/coke.jfif" width="500px" height="500px">
        </div>
      </td>
      <td>
        <p style="font-size:60px;">Beef Coke....</p>
        <p style="font-size:30px;">Rs.100/= upwards</p>
      </td>

      <td>
        <div class='brighten'>
          <img src="image/lemonade.jpg" width="500px" height="500px">
        </div>
      </td>
      <td>
        <p style="font-size:60px;">Lemonade....</p>
        <p style="font-size:30px;">Rs.200/= upwards</p>
      </td>
    </tr> -->

  </table>




  <p style="font-size:100px;"><u>Sauces....</u></p>


  <table>
    <tr>
      <td>
        <div class='brighten'>
          <img src="image/named sauce.png" width="500px" height="400px">
      </td>
      <td>
        <p></p>
        <p style="font-size:30px;">Enjoy and custermarize, <br>your burger with our sauces....</p>
      </td>
    </tr>
    </tr>
    <table>
      <br>
      <br>


      <br>
      <br><br>

      <br>
      <br><br>


      <div class="footer">
        <p>contact us....077-4334936</p>

      </div>

</body>

</html>