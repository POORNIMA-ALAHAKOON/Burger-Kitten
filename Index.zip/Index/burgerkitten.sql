-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2022 at 05:17 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `burgerkitten`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('poornima', 'poo1');

-- --------------------------------------------------------

--
-- Table structure for table `newcustable`
--

CREATE TABLE `newcustable` (
  `Full_Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Telephone_No` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `newcustable`
--

INSERT INTO `newcustable` (`Full_Name`, `Email`, `Password`, `Telephone_No`) VALUES
('', '', '', '0'),
('Hasith Alahakoon', 'hasitha123@gmail.com', 'kill', '0'),
('Jeniffer Lopes', 'jeni10@gmail.com', '00045', '0'),
('Pawani Perera', 'pavani@gmail.com', '4444', '0'),
('poo', 'palahakoon1@gmail.com', '1234', '0'),
('sadali alahakoon', 'sadali@gmail.com', '9999', ''),
('Sarah Sharosh', 'shy1234@gmail.com', '99999', '0'),
('Srah ferosh', 'sarah1234@gmail.com', 'sarahje', '0'),
('Supun ', 'supunhi@gmail.com', 'abbb', '0'),
('Supun Gamage', 'supunhi@gmail.com', 'abbb', '0'),
('Viraj Akalnka', 'akalanaka@gmail.com', 'paani1', '0');

-- --------------------------------------------------------

--
-- Table structure for table `ordertable`
--

CREATE TABLE `ordertable` (
  `Full_Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Telephone_No` int(11) NOT NULL,
  `Your_Message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ordertable`
--

INSERT INTO `ordertable` (`Full_Name`, `Email`, `Password`, `Telephone_No`, `Your_Message`) VALUES
('Maneesha Ishwari', 'maneeshaishwari1234@', '55555', 771936428, '1 table'),
('Poornima', 'palahakoon1@gmail.com', '1234', 9122, 'dddd'),
('Vijani', 'viajani91@gmail.com', '10990', 773443963, '3 tables'),
('Vijani', 'pavani00@gmail.com', '1234', 773449896, '3 tables'),
('Heshan Liyanage', 'heshan1@gmail.com', '6666', 771682438, '2 tables'),
('Janani Soorotarachchi', 'janudinu@gmail.com', 'janu@97', 764605704, '2 tables'),
('Dimuthu Pinsara', 'pinsara1@gmail.com', 'poo1', 776791234, '4 tables @2 pm'),
('Ishan Randika', 'randika@gmail.com', '1234', 773449896, '3 tables'),
('Ishan Randika', 'randika@gmail.com', '1234', 773449896, '3 tables'),
('Ishan Randika', 'randika@gmail.com', '1234', 773449896, '3 tables'),
('Ishan Randika', 'randika@gmail.com', '1234', 773449896, '3 tables'),
('Ishan Randika', 'randika@gmail.com', '1234', 773449896, '3 tables'),
('Shehan Liyanage', 'sgliyanage@gmail.com', 'sgl9', 778724123, '2  tables '),
('Randika Perera', 'rprere1@gmail.com', '123333', 773467876, '1 table');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `newcustable`
--
ALTER TABLE `newcustable`
  ADD PRIMARY KEY (`Full_Name`),
  ADD KEY `Full_Name` (`Full_Name`);

--
-- Indexes for table `ordertable`
--
ALTER TABLE `ordertable`
  ADD KEY `Full_Name` (`Full_Name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
