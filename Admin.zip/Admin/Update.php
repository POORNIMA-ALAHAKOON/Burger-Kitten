<?php
include "Connection.php";

if(isset($_GET['updateid'])){
    $product=$_GET['updateid'];

    $searchItem="SELECT `itemno`, `name`, `price`, `size`, `image` FROM `bugurs` WHERE `itemno`='$product'";

    $result=mysqli_query($conn,$searchItem);

    $row=mysqli_fetch_assoc($result);

    $product=$row['itemno'];
    $name=$row['name'];
    $price=$row['price'];
    $size=$row['size'];
}

if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $price=$_POST['price'];
    $size=$_POST['size'];

    $updateQ="UPDATE `bugurs` SET `name`='$name',`price`='$price',`size`='$size' WHERE `itemno`='$product'";

    $result=mysqli_query($conn,$updateQ);

    if($result){
        header("Location:Dashboard.php");
    }else{
        echo "Error";
    }

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Item Update</title>


</head>
<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-image: url("./Images/fresh-tasty-homemade-burger-wooden-table_147620-1307.jpg");
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        height: 100vh;
    }



    h1 {
        margin-top: 5%;
        text-align: center;
        color: white;
        font-size: 72px;
    }

    .container-fluid {
        width: 100%;
    }

    span {
        color: rgb(255, 136, 0);
    }

    form {
        position: absolute;
        width: 50%;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        border: 5px solid Orange;
    }

    input[type=text] {
        width: 70%;
        height: 35px;
        margin-bottom: 2%;
        position: relative;
        top: 50%;
        left: 50%;
        border-radius: 10px;
        transform: translate(-50%, -50%);
    }

    input[type=password] {
        width: 70%;
        height: 35px;
        position: relative;
        top: 60%;
        left: 50%;
        transform: translate(-50%, -50%);
        border-radius: 10px;
    }

    button {
        position: relative;
        top: 65%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 20%;
        height: 40px;
        border-radius: 10px;
        font-family: Arial;
        font-size: 20px;
    }

    input[type=text]:hover {
        border: 1px solid Orange;
        background-color: rgba(209, 152, 47, 0.897);
        transition: 0.1s;
    }

    input::file-selector-button:hover {
        border: 1px solid Orange;
        background-color: rgba(209, 152, 47, 0.897);
        transition: 0.1s;
    }

    button:hover {
        background-color: Orange;
        color: black;
        transition: 0.5s;
    }
</style>

<body>
    <div class="container-fluid">
        <h1>Update<span> Item</span></h1>

        <form method="POST" enctype="multipart/form-data">
            <input type="text" name="product" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                placeholder="Product ID" readonly value="<?php echo $product ?>"><br>
            <input type="text" name="name" class="form-control" id="exampleInputPassword1" placeholder="Name" value="<?php echo $name ?>">
            <br>
            <input type="text" name="price" class="form-control" id="exampleInputPassword1" placeholder="Price" value="<?php echo $price ?>">
            <br>
            <input type="text" name="size" class="form-control" id="exampleInputPassword1" placeholder="Size" value="<?php echo $size ?>">
            <br>
            <br>
            <br>
            <button type="submit" name="submit" class="btn btn-primary">UPDATE</button>
        </form>
    </div>
</body>

</html>