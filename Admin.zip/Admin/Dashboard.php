<?php
include "Connection.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<style>
    body{
        font-family:'Arial';
    }
    h1 {
        text-align: center;
        color: black;
    }

    span {
        color: orange;
    }

    .btn_sec {
        margin-top: 5%;
    }

    .btn_sec button {
        position: relative;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    .table_sec {
        margin-top: 5%;
        width: 90%;
    }

    .add_btn {
        width: 150px;
        height: 50px;
        border-radius: 10px;
        font-family: 'Segoe UI';
        font-weight: bold;
        font-size: 20px
    }

    .add_btn:hover {
        background-color: orange;
        transition: 0.5s;
    }

    table {
        width: 90%;
        position: relative;
        left:55%;
        transform:translate(-50%,0%);
        text-align:center;
        font-family:'Arial';
    }

    .btn{
        width: 150px;
        height: 40px;
        border-radius: 10px;
        font-family: 'Segoe UI';
        font-weight: bold;
        font-size: 15px;
        margin-top:20px;
    }

    #update:hover{
        background-color:orange;
        transition: 0.5s;
    }

    #delete:hover{
        background-color:red;
        color:white;
        transition: 0.5s;
    }

    a{
        text-decoration:none;
        color:black;
    }

    img{
        width: 75px;
    }
</style>

<body>
    <header>
    <div class="container btn_sec">
        <a href="./AddItem.php"><button type="button" class="add_btn">Add Item</button></a><br><br>
        <a href="../menuNEW.php"><button type="button" class="add_btn">Main Page</button></a>
    </div>
    <div class="container-fluid">
        <h1>Welocme To <span>Bugger King</span> Admin Panel</h1>
    </div>
    </header>
    <div class="container-fluid table_sec">
        <table border=1>
            <thead>
                <tr>
                    <th scope="col">Item No</th>
                    <th scope="col">Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Size</th>
                    <th scope="col">Image</th>
                    <th scope="col">Option</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $searchAllQ="SELECT * FROM `bugurs`";

                    $result=mysqli_query($conn,$searchAllQ);

                    if($result){
                        // echo "Good";
                    }else{
                        // echo "Error";
                    }
                    while($row=mysqli_fetch_assoc($result)){
                        $product=$row['itemno'];
                        $name=$row['name'];
                        $price=$row['price'];
                        $size=$row['size'];
                        $image=$row['image'];
                    ?>
                <tr>
                    <th scope="row"><?php echo $product ?></th>
                    <td><?php echo $name ?></td>
                    <td><?php echo $price ?></td>
                    <td><?php echo $size ?></td>
                    <td><img src="./Items/<?php echo $image ?>"></td>
                    <td>
                        <button class="btn" id="update"><a href="Update.php? updateid=<?php echo $product ?>">Update</button></a>
                        <button class="btn" id="delete"><a href="Delete.php? deleteid=<?php echo $product; ?>">Delete</button></a><br>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>

</html>