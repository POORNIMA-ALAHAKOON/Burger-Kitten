<?php

include "Connection.php";

if(isset($_GET['deleteid'])){
    $product=$_GET['deleteid'];

    $deleteQ="DELETE FROM `bugurs` WHERE `itemno`='$product'";

    $result=mysqli_query($conn,$deleteQ);
    if($result){
        header("Location:Dashboard.php");
    }else{
        // echo "error Q";
    }
}

?>