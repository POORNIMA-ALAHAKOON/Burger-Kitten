<?php
include "Connection.php";

$type_username=mysqli_real_escape_String($conn,$_POST['Username']);
$type_password=mysqli_real_escape_String($conn,$_POST['password']);

$searchQuery="SELECT `username`, `password` FROM `admin` WHERE `username`='$type_username'";

$result=mysqli_query($conn,$searchQuery);

$row=mysqli_fetch_assoc($result);

$username=$row['username'];
$password=$row['password'];

if($type_username!=$username) {
    echo "<script>
    window.location.href = 'http://localhost/BurgerKitten/Admin/AdminLogin.php';
    alert('Invalid Username !');
</script>";
}else if($type_password!=$password){
    echo "<script>
      window.location.href = 'http://localhost/BurgerKitten/Admin/AdminLogin.php';
      alert('Invalid Password !');
</script>";
}else{
    header("Location:Dashboard.php");
}

?>
